from django.contrib import admin
# from .models import Estimate
from .models import BookingTable
# from import_export.admin import ImportExportModelAdmin

# Register your models here.

class Bookingview(admin.ModelAdmin):
    list_display=['name','email','phone_number','person','caf','dateTime','Note']
admin.site.register(BookingTable,Bookingview)
