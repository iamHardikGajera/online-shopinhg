from django.db import models

# Create your models here.

class BookingTable(models.Model):
    name = models.CharField(max_length=20)
    email= models.EmailField()
    phone_number = models.CharField(max_length=20)
    person = models.CharField(max_length=3,choices=(
        ('1',"1"),
        ('2',"2"),
        ('3',"3"),
        ('4',"4"),
        ('5',"5"),
        ('6',"6"),
        ('7',"7"),
        ('8',"8"),
        ('9',"9"),
        ('10',"10"),
        ('11',"11"),
        ('12',"12"),
        ('13',"13"),
        ('14',"14"),
        ('15',"15"),
        ('16',"16"),
        ('17',"17"),
        ('18',"18"),
        ('19',"19"),
        ('20',"20"),
        

    ))

    caf = models.CharField(max_length=31,choices=(
        ('Gamysticafe',"Gamysticafe"),
        ('Cafe Mocha',"Cafe Mocha"),
        ('Game On Cafe',"Game On Cafe"),
        ('Java+',"Java+"),
        ('The Hideout Cafe',"The Hideout Cafe"),
        ('Beach Vibes Cafe',"Beach Vibes Cafe"),
        ('Skryf',"Skryf"),
        ('Sundae Delight cafe n ice cream',"Sundae Delight cafe n ice cream"),
        ('Virescent Cafe',"Virescent Cafe"),
    ))
    
    dateTime = models.DateTimeField(auto_now_add=False)
    Note = models.CharField(max_length=25)
    