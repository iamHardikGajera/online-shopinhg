from django.urls import path
from . import views
from .views import BookingForm
urlpatterns = [
    path('',views.BookingForm,name="BookingForm"),
    #path("EstimateView/", EstimateView.as_view(), name="EstimateView"),
]
