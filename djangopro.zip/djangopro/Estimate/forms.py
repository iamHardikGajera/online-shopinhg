from django import forms
from .models import BookingTable

class EstimateForm(forms.ModelForm):
    class Meta:
        model = BookingTable
        fields = '__all__'
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class': 'form-control'})
        self.fields['email'].widget.attrs.update({'class': 'form-control'})
        self.fields['phone_number'].widget.attrs.update({'class': 'form-control'})
        self.fields['person'].widget.attrs.update({'class': 'form-control'})
        self.fields['dateTime'].widget.attrs.update({'class': 'form-control'})
        self.fields['Note'].widget.attrs.update({'class': 'form-control'})
        self.fields['caf'].widget.attrs.update({'class': 'form-control'})

        